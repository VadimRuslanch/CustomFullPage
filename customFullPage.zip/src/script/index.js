import '../styles/index.css';
import {initSlideController} from './slideController.js';

initSlideController({
    scrollDelay: 800,
    transitionSpeed: 1000
});
